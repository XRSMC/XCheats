try {
game["coins"] = 999999999;

  console.log("Boatrace cheats injected");
} catch (e) {
  console.error("Error injecting game cheat:", e);
}
