chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      const script = document.createElement('script');
      script.src = chrome.runtime.getURL('inject.js');
      document.documentElement.appendChild(script);
      script.remove();
    }
  });
});
