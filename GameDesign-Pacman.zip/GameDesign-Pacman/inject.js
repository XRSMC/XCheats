try {
// 🧙‍♂️ PACMAN GOD MODE + LEVEL SKIP

let godMode = false;

// 🔁 Hotkeys: I = toggle God Mode, L = level jump
document.addEventListener("keydown", (e) => {
  const key = e.key.toLowerCase();

  if (key === "i") {
    godMode = !godMode;
    alert("🛡️ God Mode " + (godMode ? "ENABLED" : "DISABLED"));
  }

  if (key === "l") {
    const input = prompt("🔢 Enter level number to jump to:");
    const level = parseInt(input);
    if (!isNaN(level) && level > 0) {
      game["pacmanLevel"] = level;
      pacmanInit(); // reload the level
      alert("🚀 Jumped to level " + level);
    } else {
      alert("⚠️ Invalid level number.");
    }
  }
});

// 🛡️ IMMORTALITY — block death
Object.defineProperty(game, "pacmanStatus", {
  get: function () {
    return this._pacmanStatus || "";
  },
  set: function (val) {
    if (godMode && val === "CAUGHT") {
      return; // block death silently
    }
    this._pacmanStatus = val;
  }
});

// ❤️ LIFE LOCK — block life loss
let internalLives = game["pacmanLives"];
Object.defineProperty(game, "pacmanLives", {
  get() {
    return internalLives;
  },
  set(val) {
    if (godMode) {
      return; // block life loss silently
    }
    internalLives = val;
  }
});


  console.log("Pacman cheats injected");
} catch (e) {
  console.error("Error injecting game cheat:", e);
}
