try {
game["playerCoins"] = 99999999999999999999999999999999999999999;

  console.log("Blob Defense cheats injected");
} catch (e) {
  console.error("Error injecting game cheat:", e);
}
