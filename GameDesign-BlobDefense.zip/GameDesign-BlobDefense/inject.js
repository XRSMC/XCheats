try {
game["playerCoins"] = 999999999;

  console.log("Blob Defense cheats injected");
} catch (e) {
  console.error("Error injecting game cheat:", e);
}
