try {
// 🧙‍♂️ FINAL CLEAN CHEATS — Immortality, Unlimited Balls, Mission Skip, Frozen UI

let godMode = false;
let unlimitedBalls = false;

// ❤️ IMMORTALITY: Prevent heart loss
let internalHearts = game["playerHearts"];
Object.defineProperty(game, "playerHearts", {
  get() {
    return internalHearts;
  },
  set(val) {
    if (godMode && val < internalHearts) return;
    internalHearts = val;
  }
});

// ♾️ UNLIMITED BALLS: prevent shot count increase
let internalMissionShot = game["missionShot"];
Object.defineProperty(game, "missionShot", {
  get() {
    return 0; // freeze counter visually
  },
  set(val) {
    if (unlimitedBalls && val > internalMissionShot) return;
    internalMissionShot = val;
  }
});

// 🎮 HOTKEYS
document.addEventListener("keydown", (e) => {
  const key = e.key.toLowerCase();

  if (key === "i") {
    godMode = !godMode;
    alert("🛡️ God Mode " + (godMode ? "ENABLED" : "DISABLED"));
  }

  if (key === "u") {
    unlimitedBalls = !unlimitedBalls;
    alert("♾️ Unlimited Balls " + (unlimitedBalls ? "ENABLED" : "DISABLED"));
  }

  if (key === "m") {
    const mission = parseInt(prompt("🎯 Enter mission number:"));
    if (!isNaN(mission) && mission >= 0) {
      setMission(mission);
      alert("🚀 Jumped to mission " + mission);
    } else {
      alert("❌ Invalid mission number.");
    }
  }

  if (key === "t") {
    setMission(1);
    alert("⏩ Skipped tutorial — Mission 1 started!");
  }
});


  console.log("Crab Attack Cheat Injected!");
} catch (e) {
  console.error("Error injecting game cheat:", e);
}
