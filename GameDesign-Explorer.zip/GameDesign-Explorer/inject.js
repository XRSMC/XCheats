try {
  // Max out resources
  game["resource1"] = 9999999;
  game["resource2"] = 9999999;
  game["resource3"] = 9999999;
  game["resource4"] = 9999999;

  // Unlock heroes
  game["heroesUnlocked"] = 5;
  game["showHeroSelect"] = true;

  console.log("Resources maxed and heroes unlocked!");
} catch (e) {
  console.error("Error injecting game cheat:", e);
}
