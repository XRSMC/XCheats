try {
// 🛡️ Real God Mode toggle with "I" — cars can't kill, words work, next word works too

let godMode = false;
let originalCarRender = carRender;

document.addEventListener("keydown", (e) => {
  if (e.key.toLowerCase() === "i") {
    godMode = !godMode;

    if (godMode) {
      alert("🛡️ God Mode ENABLED");

      carRender = function (thisAhead) {
        tempHit = false;
        tempHitCorrectSyllable = false;

        Object.keys(o).reverse().forEach(function (key) {
          const obj = o[key];

          if (
            (obj.category === "car" || obj.category === "syllable") &&
            ((thisAhead && obj.y <= game["carY"] - game["horizon"]) ||
              (!thisAhead && obj.y > game["carY"] - game["horizon"]))
          ) {
            if (
              obj.car >= 6 &&
              obj.y + game["horizon"] >= game["carY"] - game["carLength"] &&
              obj.y + game["horizon"] < game["carY"]
            ) {
              const carLeft = game["carX"] - game["carWidth" + game["car"]] / 2;
              const carRight = game["carX"] + game["carWidth" + game["car"]] / 2;
              const oppLeft = obj.x - game["carWidth" + obj.car] / 2;
              const oppRight = obj.x + game["carWidth" + obj.car] / 2;

              const isColliding =
                (carRight > oppLeft && carRight < oppRight) ||
                (carLeft > oppLeft && carLeft < oppRight) ||
                (carLeft < oppLeft && carRight > oppRight);

              if (isColliding && !obj.isHit) {
                if (obj.category === "car") {
                  // 🛡️ IMMORTALITY: skip crash
                  obj.isHit = true;
                }

                if (obj.category === "syllable") {
                  const correct = obj.syllable === game["wordSyllable"][game["wordSyllableCount"]];
                  if (correct) {
                    tempHitCorrectSyllable = true;
                    obj.isHit = true;
                  } else {
                    playSound("error");
                  }
                }
              }
            }

            // 🖼️ Drawing
            if (obj.category === "car") {
              const size = obj.y + 20;
              drawImage(
                manifest["car_" + obj.car],
                obj.x,
                game["horizon"] + obj.y,
                size * 2,
                size,
                obj.r,
                false,
                false,
                true
              );
            } else if (obj.category === "syllable") {
              if (obj.syllable !== "-") {
                const size = obj.y / 3 + 5;
                spot["WORD"].font = "bold " + size + "px Arial";
                spot["WORD"].color = "#000000";
                drawText(obj.syllable, "WORD", obj.x, game["horizon"] + obj.y - size / 20);
                spot["WORD"].color = "#FFFFFF";
                drawText(obj.syllable, "WORD", obj.x, game["horizon"] + obj.y);
              }

              if (obj.isHit) delete o[key];
            }
          }
        });

        // ✅ Correct syllable logic: move to next word properly
        if (tempHitCorrectSyllable) {
          playSound("bonus");
          game["score"] += 10;
          game["wordTyped"] += game["wordSyllable"][game["wordSyllableCount"]];

          if (game["wordSyllableCount"] + 1 >= game["wordSyllable"].length) {
            const oldSyllable = game["wordSyllable"][game["wordSyllableCount"]];
            wlNewWord();

            // If list ends, reset it and pick a new one
            if (game["word"] === "-") {
              playSound("car_leave");
              wlInit(completeWL);
              wlNewWord();
            }

            // Replace old syllables with new
            for (let key in o) {
              if (o[key].category === "syllable") {
                o[key].syllable =
                  o[key].syllable === oldSyllable
                    ? game["wordSyllable"][game["wordSyllableCount"]]
                    : wlRandomSyllable();
              }
            }
          } else {
            // Just go to next syllable
            game["wordSyllableCount"]++;
            game["wordCount"] = game["wordFrequency"];

            for (let key in o) {
              if (o[key].category === "syllable") {
                o[key].syllable =
                  o[key].syllable === game["wordSyllable"][game["wordSyllableCount"] - 1]
                    ? game["wordSyllable"][game["wordSyllableCount"]]
                    : wlRandomSyllable();
              }
            }
          }
        }

        context.globalAlpha = 1;
      };
    } else {
      alert("🛡️ God Mode DISABLED");
      carRender = originalCarRender;
    }
  }
});




  console.log("Speed Chaser Cheats Injected!");
} catch (e) {
  console.error("Error injecting game cheat:", e);
}
