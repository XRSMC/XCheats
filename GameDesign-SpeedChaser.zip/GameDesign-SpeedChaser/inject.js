try {
// 🧙‍♂️ Toggleable Ghost Mode for Speed Chaser with key "I"

let ghostMode = false;
let originalCarRenderBackup = carRender; // Save the original

document.addEventListener("keydown", function (e) {
  if (e.key.toLowerCase() === "i") {
    ghostMode = !ghostMode;

    if (ghostMode) {
      // 👻 Activate ghost mode
      carRender = (function (originalFn) {
        return function (thisAhead) {
          tempHit = false;
          tempHitCorrectSyllable = false;

          Object.keys(o).reverse().forEach(function (key) {
            const obj = o[key];
            if (
              (obj.category === "car" || obj.category === "syllable") &&
              ((thisAhead && obj.y <= game["carY"] - game["horizon"]) ||
                (!thisAhead && obj.y > game["carY"] - game["horizon"]))
            ) {
              if (obj.y < 10) context.globalAlpha = obj.y / 10;
              else context.globalAlpha = 1;

              if (
                obj.car >= 6 &&
                obj.y + game["horizon"] >= game["carY"] - game["carLength"] &&
                obj.y + game["horizon"] < game["carY"]
              ) {
                const carLeft = game["carX"] - game["carWidth" + game["car"]] / 2;
                const carRight = game["carX"] + game["carWidth" + game["car"]] / 2;
                const oppLeft = obj.x - game["carWidth" + obj.car] / 2;
                const oppRight = obj.x + game["carWidth" + obj.car] / 2;

                if (
                  (carRight > oppLeft && carRight < oppRight) ||
                  (carLeft > oppLeft && carLeft < oppRight) ||
                  (carLeft < oppLeft && carRight > oppRight)
                ) {
                  obj.y -= 4;

                  if (obj.x > 500 && obj.x < 900) {
                    if (
                      (obj.x <= game["carX"] && game["carXspeed"] <= 0) ||
                      (obj.x >= game["carX"] && game["carXspeed"] >= 0)
                    ) {
                      let tempMove = game["carXspeed"] * 0.9;
                      if (tempMove > 0 && tempMove < 2) tempMove = 2;
                      if (tempMove <= 0 && tempMove > -2) tempMove = -2;
                      obj.x += tempMove;
                    }
                  }

                  // 🧼 SKIP crash logic
                  if (obj.category === "syllable" && !obj.isHit) {
                    if (
                      obj.syllable === game["wordSyllable"][game["wordSyllableCount"]]
                    ) {
                      tempHitCorrectSyllable = true;
                    } else {
                      playSound("error");
                    }
                  }

                  if (obj.category === "car" && !obj.isHit) {
                    // Skip sound, crash, and life loss
                  }

                  obj.isHit = true;
                }
              }

              if (obj.category === "car") {
                const size = obj.y + 20;
                drawImage(
                  manifest["car_" + obj.car],
                  obj.x,
                  game["horizon"] + obj.y,
                  size * 2,
                  size,
                  obj.r,
                  false,
                  false,
                  true
                );
              } else {
                if (obj.syllable !== "-") {
                  const size = obj.y / 3 + 5;
                  spot["WORD"].font = "bold " + size + "px Arial";
                  spot["WORD"].color = "#000000";
                  drawText(obj.syllable, "WORD", obj.x, game["horizon"] + obj.y - size / 20);
                  spot["WORD"].color = "#FFFFFF";
                  drawText(obj.syllable, "WORD", obj.x, game["horizon"] + obj.y);
                }

                if (obj.isHit) delete o[key];
              }
            }
          });

          if (tempHitCorrectSyllable) {
            playSound("bonus");
            game["score"] += 10;
            game["wordTyped"] += game["wordSyllable"][game["wordSyllableCount"]];
          }

          context.globalAlpha = 1;
        };
      })(carRender);

      alert("🧙‍♂️ Ghost Mode ENABLED — you’re untouchable!");
    } else {
      // 🚫 Disable ghost mode: restore original
      carRender = originalCarRenderBackup;
      alert("🧙‍♂️ Ghost Mode DISABLED — collisions are back on.");
    }
  }
});



  console.log("Speed Chaser Cheats Injected!");
} catch (e) {
  console.error("Error injecting game cheat:", e);
}
