try {
  // === Super Pablo Cheat Engine v4 (Fly, Immortal, Teleport, No-Fall) === //

  let flyEnabled = false;
  let immortalEnabled = false;
  let noFallEnabled = false;
  let flyInterval, immortalInterval, noFallInterval;

  document.addEventListener("keydown", (e) => {
    const key = e.key.toLowerCase();

    // 🕊️ Fly Mode toggle (F)
    if (key === "f") {
      flyEnabled = !flyEnabled;

      if (flyEnabled) {
        console.log("🕊️ Fly Mode ON");
        flyInterval = setInterval(() => {
          game.gravity = 0;

          if (typeof GameCharacter !== "undefined") {
            GameCharacter.Movement = "idle";
            GameCharacter.JumpCounter = 0;
            GameCharacter.Grounded = true;
          }

          if (pressedKeys[37] || pressedKeys[65]) game.CharacterX -= 10; // Left
          if (pressedKeys[39] || pressedKeys[68]) game.CharacterX += 10; // Right
          if (pressedKeys[38] || pressedKeys[87]) game.CharacterY -= 10; // Up
          if (pressedKeys[40] || pressedKeys[83]) game.CharacterY += 10; // Down
        }, 30);
      } else {
        clearInterval(flyInterval);
        game.gravity = 1.5;
        console.log("🕊️ Fly Mode OFF");
      }
    }

    // 🧙 Immortality toggle (I)
    if (key === "i") {
      immortalEnabled = !immortalEnabled;

      if (immortalEnabled) {
        console.log("🧙 Immortality ON");
        immortalInterval = setInterval(() => {
          game.die = false;
          game.gameover = false;
          game.DieTimer = 0;
        }, 50);
      } else {
        clearInterval(immortalInterval);
        console.log("🧙 Immortality OFF");
      }
    }

    // 🚀 Level teleport (L)
    if (key === "l") {
      let level = prompt("🚀 Which level do you want to go to?");
      if (level && !isNaN(level)) {
        game.level = parseInt(level);
        StartLevel(game.level);
        console.log("🚀 Teleported to Level " + game.level);
      } else {
        console.log("❌ Invalid level input.");
      }
    }

    // 🌌 No-Fall Recovery toggle (N)
    if (key === "n") {
      noFallEnabled = !noFallEnabled;

      if (noFallEnabled) {
        console.log("🌌 No-Fall ON — You’ll never fall out of the map.");
        noFallInterval = setInterval(() => {
          if (game.CharacterY > 750) {
            game.CharacterY = 100;
            game["Camera-Y"] = 0;
            game.DieTimer = 0;
            game.die = false;
            game.gameover = false;

            if (typeof GameCharacter !== "undefined") {
              GameCharacter.Movement = "idle";
              GameCharacter.JumpCounter = 0;
            }

            console.log("🔁 Saved from falling!");
          }
        }, 100);
      } else {
        clearInterval(noFallInterval);
        console.log("🌌 No-Fall OFF");
      }
    }
  });

  console.log("✅ Super Pablo Cheat Engine v4 loaded successfully!");
} catch (e) {
  console.error("❌ Cheat Engine failed to load:", e);
}
