try {
  // Max out resources
  game["coins"] = 99999999999;

  console.log("Resources maxed and heroes unlocked!");
} catch (e) {
  console.error("Error injecting game cheat:", e);
}
